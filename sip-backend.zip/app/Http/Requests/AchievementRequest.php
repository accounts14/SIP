<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AchievementRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        if ($this->isMethod('get')) {
			return true;
		} else if ($this->isMethod('post')) {
			return true;
		} else {
			return true;
		}
        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        if ($this->isMethod('get')) {
			return [];
		}
        return [
            'school_id'     => 'required',
            'name'          => 'required|max:150',
            'level'         => 'required',
            'achieved_at'   => 'required',
            'achieved_by'   => 'required',
            'achieved_from' => 'required|max:200',
        ];
    }
}
